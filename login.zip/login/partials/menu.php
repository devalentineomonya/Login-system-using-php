<link rel="stylesheet" href="../css/styles.css">

<div class="menu">
   <div class="logo">
<p>Authentication System</p>
   </div>
   <div class="top_nav">
      <ul>
         <li><a href="home.php">Home</a></li>
         <li><a href="admin_list.php">Admin</a></li>
         <li><a href="logout.php">LogOut</a></li>
      </ul>
   </div>
</div>