<link rel="stylesheet" href="../css/styles.css">

<div class="footer">
   <p>This website was Designed by ByTech Solutions</p>
</div>